﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace XpenseManagerApp
{
    /// <summary>
    /// Interaction logic for UpdateExpense.xaml
    /// </summary>
    public partial class UpdateExpense : UserControl
    {
        int updateId;
        public UpdateExpense()
        {
            InitializeComponent();
            DisplayinGrid();
        }

        public void DisplayinGrid()
        {
            dgExpenseStorage.ItemsSource = App._datastorage;
            float totalSpent = (from expense in App._datastorage
                                select expense.totalAmount).Sum();
            SpentTotal.Text = totalSpent.ToString();
        }

        private void txtboxFilter_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (txtboxFilter.Text == null || txtboxFilter.Text.Equals(""))
            {
                dgExpenseStorage.ItemsSource = App._datastorage;
                float totalSpent = (from expense in App._datastorage
                                    select expense.totalAmount).Sum();
                SpentTotal.Text = totalSpent.ToString();
            }
            else
            {
                dgExpenseStorage.SelectedItem = null;
                var filterResult = (
                    from expense in App._datastorage
                    where (expense.productId.ToString().
                        StartsWith(txtboxFilter.Text, StringComparison.InvariantCultureIgnoreCase)
                        || expense.itemName.StartsWith(txtboxFilter.Text,
                        StringComparison.InvariantCultureIgnoreCase)
                        || expense.itemPrice.ToString().
                        StartsWith(txtboxFilter.Text,
                           StringComparison.InvariantCultureIgnoreCase)
                        || expense.itemQuantity.ToString().StartsWith(txtboxFilter.Text,
                           StringComparison.InvariantCultureIgnoreCase)
                        || expense.totalAmount.ToString().StartsWith(txtboxFilter.Text,
                           StringComparison.InvariantCultureIgnoreCase)
                        || expense.category.StartsWith(txtboxFilter.Text,
                        StringComparison.InvariantCultureIgnoreCase)
                        || expense.boughtDate.StartsWith(txtboxFilter.Text,
                        StringComparison.InvariantCultureIgnoreCase)
                        )
                    select expense);
                dgExpenseStorage.ItemsSource = filterResult;
            }
        }

        private void dgExpenseStorage_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                int filterIdValue = 0;
                int totalItems = (from expense in App._datastorage
                                  select expense.productId).LastOrDefault();
                if (txtboxFilter.Text == null || txtboxFilter.Text.Equals(""))
                { }
                else
                {
                    filterIdValue = Int32.Parse(txtboxFilter.Text);
                }

                if (totalItems >= filterIdValue || dgExpenseStorage.SelectedItem != null)
                {
                    if (dgExpenseStorage.SelectedItem != null)
                    {
                        string setComboBox = "Grocery";
                        object item = dgExpenseStorage.SelectedItem;
                        string ID = (dgExpenseStorage.SelectedCells[0].Column.GetCellContent(item)
                            as TextBlock).Text;
                        updateId = int.Parse(ID);
                        var itemToUpdate = (from expense in App._datastorage
                                            where (expense.productId == updateId)
                                            select expense);
                        itemToUpdate.Where(exp => exp.productId == updateId)
                            .ToList().ForEach(exp =>
                            {
                                ItemNameTxtBx.Text = exp.itemName;
                                DatePickedValue.Text = exp.boughtDate;
                                ItemPriceTxtBx.Text = exp.itemPrice.ToString();
                                ItemQuantityTxtBx.Text = exp.itemQuantity.ToString();
                                setComboBox = exp.category;
                            });
                        int x = 0;
                        int lastMatch = 0;
                        string match = setComboBox;
                        // If the search string is empty set to begining of textBox
                        if (setComboBox.Length != 0)
                        {
                            bool found = true;
                            while (found)
                            {
                                if (comboboxList.Items.Count == x)
                                {
                                    comboboxList.SelectedIndex = lastMatch;
                                    found = false;
                                }
                                else
                                {
                                    comboboxList.SelectedIndex = x;
                                    match = comboboxList.SelectedValue.ToString();
                                    if (match.Contains(setComboBox))
                                    {
                                        lastMatch = x;
                                        found = false;
                                    }
                                    x++;
                                }
                            }
                        }
                        else
                            comboboxList.SelectedIndex = 0;
                    }
                    StorageClass.StoreXML<List<ViewDatafromCSV>>("ExpenseManager.xml", App._datastorage);
                }
                else
                {
                    MessageBox.Show("The selected item or Filter Item is out of range.",
                        "Attention!!!");
                }

            }
            catch (System.IndexOutOfRangeException es)
            {
                MessageBox.Show(es.Message);
                // Set IndexOutOfRangeException to the new exception's InnerException.
                throw new System.ArgumentOutOfRangeException("index parameter is out of range.", es);
            }
        }

        public void Display()
        {
            App._datastorage = StorageClass.ReadXML<List<ViewDatafromCSV>>("ExpenseManager.xml");
            if (App._datastorage == null)
                App._datastorage = new List<ViewDatafromCSV>();
            dgExpenseStorage.ItemsSource = App._datastorage;
        }

        private void Save_Button_MouseLeave(object sender, MouseEventArgs e)
        {
            Save_Button.Height = 40;
            Save_Button.Width = 40;
        }

        private void Save_Button_MouseEnter(object sender, MouseEventArgs e)
        {
            Save_Button.Height = 70;
            Save_Button.Width = 70;
        }

        private void Save_Button_MouseDown(object sender, MouseButtonEventArgs e)
        {
            int countItems = App._datastorage.Count;

            countItems += 1;
            float totalPriceofItems = 0;
            string totalPrice = "";
            float totalSpent = (from expense in App._datastorage
                                select expense.totalAmount).Sum();

            if (ItemNameTxtBx.Text != null && ItemNameTxtBx.Text != "")
            {
                if (ItemQuantityTxtBx.Text != null && ItemQuantityTxtBx.Text != "")
                {
                    if (ItemPriceTxtBx.Text != null && ItemPriceTxtBx.Text != "")
                    {
                        if (DatePickedValue.Text != null && DatePickedValue.Text != "")
                        {
                            if (comboboxList.SelectedItem != null)
                            {
                                totalPrice = (Convert.ToDecimal(ItemQuantityTxtBx.Text) * Convert.ToDecimal(ItemPriceTxtBx.Text)).ToString();
                                totalPriceofItems = float.Parse(totalPrice);
                                var updateItem = (from expense in App._datastorage
                                                  where (expense.productId == updateId)
                                                  select expense);
                                updateItem
                               .Where(exp => exp.productId == updateId)
                               .ToList().ForEach(exp =>
                               {
                                   exp.itemName = ItemNameTxtBx.Text;
                                   exp.boughtDate = DatePickedValue.Text;
                                   exp.itemPrice = float.Parse(ItemPriceTxtBx.Text);
                                   exp.itemQuantity = Int32.Parse(ItemQuantityTxtBx.Text);
                                   exp.totalAmount = totalPriceofItems;
                                   exp.category = ((ComboBoxItem)comboboxList.SelectedItem).Content as string;
                               });
                                StorageClass.StoreXML<List<ViewDatafromCSV>>("ExpenseManager.xml", App._datastorage);
                                Display();
                                totalSpent = totalSpent + totalPriceofItems;
                                totalSpent = (from expense in App._datastorage
                                              select expense.totalAmount).Sum();
                                totalPrice = (Convert.ToDecimal(ItemQuantityTxtBx.Text) * Convert.ToDecimal(ItemPriceTxtBx.Text)).ToString();
                                totalPriceofItems = float.Parse(totalPrice);
                                SpentTotal.Text = "";
                                SpentTotal.Text = totalSpent.ToString();

                                totalPrice = "";
                                totalSpent = 0;
                                ItemNameTxtBx.Text = null;
                                ItemQuantityTxtBx.Text = null;
                                ItemPriceTxtBx.Text = null;
                                DatePickedValue.Text = null;
                                comboboxList.SelectedIndex = 0;
                                MessageBox.Show("Item Expense Updated!", "Alert!!!");

                            }
                            else
                            {
                                MessageBox.Show("Please select a category from the list!",
                                    "ALERT!!!");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Fill All Fields!", "Error!!!");
                            Keyboard.Focus(DatePickedValue);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Fill All Fields!", "Error!!!");
                        Keyboard.Focus(ItemPriceTxtBx);
                    }
                }
                else
                {
                    MessageBox.Show("Fill All Fields!", "Error!!!");
                    Keyboard.Focus(ItemQuantityTxtBx);
                }
            }
            else
            {
                MessageBox.Show("Fill All Fields!", "Error!!!");
                Keyboard.Focus(ItemNameTxtBx);
            }
        }
    }
}