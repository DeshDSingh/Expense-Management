﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace XpenseManagerApp
{
    /// <summary>
    /// Interaction logic for AddNewExpense.xaml
    /// </summary>
    public partial class AddNewExpense : UserControl
    {
        int countItems;
        public AddNewExpense()
        {
            InitializeComponent();
            datgridExpenseStorage.ItemsSource = App._datastorage;
            float totalSpent = (from expense in App._datastorage
                                select expense.totalAmount).Sum();
            SpentTotal.Text = totalSpent.ToString();
        }

        //private void SaveBtnTxtBtn_Click(object sender, RoutedEventArgs e)
        //{
        //    int countItems = App._datastorage.Count;
        //    float totalSpent = (from expense in App._datastorage
        //                        select expense.totalAmount).Sum();
        //    countItems += 1;
        //    var totalPrice = (Convert.ToDecimal(ItemQuantityTxtBx.Text) * Convert.ToDecimal(ItemPriceTxtBx.Text)).ToString();
        //    float totalPriceofItems = float.Parse(totalPrice);
        //    totalSpent = totalSpent + totalPriceofItems;
        //    SpentTotal.Text = totalSpent.ToString();
        //    if (ItemNameTxtBx.Text != null && ItemNameTxtBx.Text != "")
        //    {
        //        if (ItemQuantityTxtBx.Text != null && ItemQuantityTxtBx.Text != "")
        //        {
        //            if (ItemPriceTxtBx.Text != null && ItemPriceTxtBx.Text != "")
        //            {
        //                if (DatePickedValue.Text != null && DatePickedValue.Text != "")
        //                {
        //                    if (comboboxList.SelectedItem != null)
        //                    {
        //                        ViewDatafromCSV datastore = new ViewDatafromCSV
        //                        {
        //                            productId = countItems,
        //                            itemName = ItemNameTxtBx.Text,
        //                            boughtDate = DatePickedValue.Text,
        //                            itemPrice = float.Parse(ItemPriceTxtBx.Text),
        //                            itemQuantity = Int32.Parse(ItemQuantityTxtBx.Text),
        //                            totalAmount = totalPriceofItems,
        //                            category = ((ComboBoxItem)comboboxList.SelectedItem).Content as string
        //                        };

        //                        App._datastorage.Add(datastore);
        //                        StorageClass.StoreXML<List<ViewDatafromCSV>>("ExpenseManager.xml", App._datastorage);
        //                        Display();
        //                        totalSpent = 0;
        //                        ItemNameTxtBx.Text = "";
        //                        ItemQuantityTxtBx.Text = "";
        //                        ItemPriceTxtBx.Text = "";
        //                        DatePickedValue.Text = "";
        //                        comboboxList.SelectedIndex = 0;
        //                        MessageBox.Show("Item Expense Saved!", "Alert!!!");
        //                    }
        //                    else
        //                    {
        //                        MessageBox.Show("Fill All Fields!", "Error!!!");
        //                        Keyboard.Focus(comboboxList);
        //                    }
        //                }
        //                else
        //                {
        //                    MessageBox.Show("Fill All Fields!", "Error!!!");
        //                    Keyboard.Focus(DatePickedValue);
        //                }
        //            }
        //            else
        //            {
        //                MessageBox.Show("Fill All Fields!", "Error!!!");
        //                Keyboard.Focus(ItemPriceTxtBx);
        //            }
        //        }
        //        else
        //        {
        //            MessageBox.Show("Fill All Fields!", "Error!!!");
        //            Keyboard.Focus(ItemQuantityTxtBx);
        //        }
        //    }
        //    else
        //    {
        //        MessageBox.Show("Fill All Fields!", "Error!!!");
        //        Keyboard.Focus(ItemNameTxtBx);
        //    }

        //}

        public void Display()
        {
            App._datastorage = StorageClass.ReadXML<List<ViewDatafromCSV>>("ExpenseManager.xml");
            if (App._datastorage == null)
                App._datastorage = new List<ViewDatafromCSV>();
            datgridExpenseStorage.ItemsSource = App._datastorage;
        }

        private void Save_Button_MouseLeave(object sender, MouseEventArgs e)
        {
            //Save_Button.Height = 40;
            //Save_Button.Width = 40;
        }

        private void Save_Button_MouseEnter(object sender, MouseEventArgs e)
        {
            //Save_Button.Height = 70;
            //Save_Button.Width = 70;
        }

        private void Save_Button_MouseDown(object sender, MouseButtonEventArgs e)
        {
            //int countItems = App._datastorage.Count;
            //float totalSpent = (from expense in App._datastorage
            //                    select expense.totalAmount).Sum();
            //countItems += 1;
            //string totalPrice = "";
            //float totalPriceofItems = 0;
            //totalSpent = totalSpent + totalPriceofItems;
            //SpentTotal.Text = totalSpent.ToString();
            //if (ItemNameTxtBx.Text != null && ItemNameTxtBx.Text != "")
            //{
            //    if (ItemQuantityTxtBx.Text != null && ItemQuantityTxtBx.Text != "")
            //    {
            //        if (ItemPriceTxtBx.Text != null && ItemPriceTxtBx.Text != "")
            //        {
            //            if (DatePickedValue.Text != null && DatePickedValue.Text != "")
            //            {
            //                if (comboboxList.SelectedItem != null)
            //                {
            //                    totalPrice = (Convert.ToDecimal(ItemQuantityTxtBx.Text) * Convert.ToDecimal(ItemPriceTxtBx.Text)).ToString();
            //                    totalPriceofItems = float.Parse(totalPrice);
            //                    ViewDatafromCSV datastore = new ViewDatafromCSV
            //                    {
            //                        productId = countItems,
            //                        itemName = ItemNameTxtBx.Text,
            //                        boughtDate = DatePickedValue.Text,
            //                        itemPrice = float.Parse(ItemPriceTxtBx.Text),
            //                        itemQuantity = Int32.Parse(ItemQuantityTxtBx.Text),
            //                        totalAmount = totalPriceofItems,
            //                        category = ((ComboBoxItem)comboboxList.SelectedItem).Content as string
            //                    };

            //                    App._datastorage.Add(datastore);
            //                    StorageClass.StoreXML<List<ViewDatafromCSV>>("ExpenseManager.xml", App._datastorage);
            //                    Display();
            //                    totalSpent = 0;
            //                    ItemNameTxtBx.Text = "";
            //                    ItemQuantityTxtBx.Text = "";
            //                    ItemPriceTxtBx.Text = "";
            //                    DatePickedValue.Text = "";
            //                    comboboxList.SelectedIndex = 0;
            //                    MessageBox.Show("Item Expense Saved!", "Alert!!!");
            //                }
            //                else
            //                {
            //                    MessageBox.Show("Fill All Fields!", "Error!!!");
            //                    Keyboard.Focus(comboboxList);
            //                }
            //            }
            //            else
            //            {
            //                MessageBox.Show("Fill All Fields!", "Error!!!");
            //                Keyboard.Focus(DatePickedValue);
            //            }
            //        }
            //        else
            //        {
            //            MessageBox.Show("Fill All Fields!", "Error!!!");
            //            Keyboard.Focus(ItemPriceTxtBx);
            //        }
            //    }
            //    else
            //    {
            //        MessageBox.Show("Fill All Fields!", "Error!!!");
            //        Keyboard.Focus(ItemQuantityTxtBx);
            //    }
            //}
            //else
            //{
            //    MessageBox.Show("Fill All Fields!", "Error!!!");
            //    Keyboard.Focus(ItemNameTxtBx);
            //}
        }

        public void Save_All_Values()
        {
            countItems = App._datastorage.Count;
            float totalSpent = (from expense in App._datastorage
                                select expense.totalAmount).Sum();
            countItems += 1;
            string totalPrice = "";
            float totalPriceofItems = 0;
            totalSpent = totalSpent + totalPriceofItems;
            SpentTotal.Text = totalSpent.ToString();
            if (ItemNameTxtBx.Text != null && ItemNameTxtBx.Text != "")
            {
                if (ItemQuantityTxtBx.Text != null && ItemQuantityTxtBx.Text != "")
                {
                    if (ItemPriceTxtBx.Text != null && ItemPriceTxtBx.Text != "")
                    {
                        if (DatePickedValue.Text != null && DatePickedValue.Text != "")
                        {
                            if (comboboxList.SelectedItem != null)
                            {
                                totalPrice = (Convert.ToDecimal(ItemQuantityTxtBx.Text) * Convert.ToDecimal(ItemPriceTxtBx.Text)).ToString();
                                totalPriceofItems = float.Parse(totalPrice);
                                ViewDatafromCSV datastore = new ViewDatafromCSV
                                {
                                    productId = countItems,
                                    itemName = ItemNameTxtBx.Text,
                                    boughtDate = DatePickedValue.Text,
                                    itemPrice = float.Parse(ItemPriceTxtBx.Text),
                                    itemQuantity = Int32.Parse(ItemQuantityTxtBx.Text),
                                    totalAmount = totalPriceofItems,
                                    category = ((ComboBoxItem)comboboxList.SelectedItem).Content as string
                                };

                                App._datastorage.Add(datastore);
                                StorageClass.StoreXML<List<ViewDatafromCSV>>("ExpenseManager.xml", App._datastorage);
                                Display();
                                totalSpent = 0;
                                ItemNameTxtBx.Text = "";
                                ItemQuantityTxtBx.Text = "";
                                ItemPriceTxtBx.Text = "";
                                DatePickedValue.Text = "";
                                comboboxList.SelectedIndex = 0;
                                MessageBox.Show("Item Expense Saved!", "Alert!!!");
                            }
                            else
                            {
                                //MessageBox.Show("Fill All Fields!", "Error!!!");
                                //Keyboard.Focus(comboboxList);
                            }
                        }
                        else
                        {
                            //MessageBox.Show("Fill All Fields!", "Error!!!");
                            //Keyboard.Focus(DatePickedValue);
                        }
                    }
                    else
                    {
                        //MessageBox.Show("Fill All Fields!", "Error!!!");
                        //Keyboard.Focus(ItemPriceTxtBx);
                    }
                }
                else
                {
                    //MessageBox.Show("Fill All Fields!", "Error!!!");
                    //Keyboard.Focus(ItemQuantityTxtBx);
                }
            }
            else
            {
                //MessageBox.Show("Fill All Fields!", "Error!!!");
                //Keyboard.Focus(ItemNameTxtBx);
            }
        }

        private void ItemNameTxtBx_TextChanged(object sender, TextChangedEventArgs e)
        {
            Save_All_Values();
        }

        private void DatePickedValue_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            Save_All_Values();
        }

        private void comboboxList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Save_All_Values();
        }
    }
}
