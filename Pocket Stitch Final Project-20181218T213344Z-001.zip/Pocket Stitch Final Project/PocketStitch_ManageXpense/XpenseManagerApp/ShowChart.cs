﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XpenseManagerApp
{
    public class ShowChart
    {
        public ShowChart(int productIds, string itemNames,
            string boughtDates, float itemPrices, int itemQuantities,
            float totalAmounts, string categories)
        {
            productId = productIds;
            itemName = itemNames;
            boughtDate = boughtDates;
            itemPrice = itemPrices;
            itemQuantity = itemQuantities;
            totalAmount = totalAmounts;
            category = categories;

        }

        public ShowChart()
        { }

        public int productId { get; set; }
        public string itemName { get; set; }
        public string boughtDate { get; set; }
        public float itemPrice { get; set; }
        public int itemQuantity { get; set; }
        public float totalAmount { get; set; }
        public string category { get; set; }
    }
}
