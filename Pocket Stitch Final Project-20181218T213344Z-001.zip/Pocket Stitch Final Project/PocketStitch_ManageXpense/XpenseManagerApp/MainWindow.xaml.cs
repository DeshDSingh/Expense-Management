﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Resources;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Excel = Microsoft.Office.Interop.Excel;

namespace XpenseManagerApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string strLanguage = "";
        String strGender = "";
        string strCurrency = "";
        string saveUserImage = "";
        Boolean boolInit = true;
        UpdateExpense updateExpense = new UpdateExpense();
        AddNewExpense addNewExpense = new AddNewExpense();
        ViewExpense viewExpense = new ViewExpense();

        public MainWindow()
        {
            InitializeComponent();
            boolInit = false;
            DefaultGrid.Visibility = Visibility.Visible;
            RaiseLanguageSelectionChanged();
            RaiseCurrencySelectionChanged();
        }

        public void RaiseCurrencySelectionChanged()
        {
            Get_Currency();
            Set_Currency();
        }

        public void RaiseLanguageSelectionChanged()
        {
            Get_Language();
            Set_Language();
        }

        public void Get_Language()
        {
            App._languageStorage = StorageClass.ReadXML<List<LanguageSettings>>("LanguageManageExpense.xml");
            if (App._languageStorage == null)
                App._languageStorage = new List<LanguageSettings>();
            var readlang = App._languageStorage;
            string setComboBox = "English";

            foreach (ComboBoxItem str in comboBoxLanguages.Items)
            {
                var updateItem = (from sett in App._languageStorage
                                  select sett);
                updateItem
                    .ToList().ForEach(exp =>
                    {
                        setComboBox = exp.choosenLanguage;
                    });
            }
            int x = 0;
            int lastMatch = 0;
            string match = setComboBox;
            // If the search string is empty set to begining of textBox
            if (setComboBox.Length != 0)
            {
                bool found = true;
                while (found)
                {
                    if (comboBoxLanguages.Items.Count == x)
                    {
                        comboBoxLanguages.SelectedIndex = lastMatch;
                        found = false;
                    }
                    else
                    {
                        comboBoxLanguages.SelectedIndex = x;
                        match = comboBoxLanguages.SelectedValue.ToString();
                        if (match.Contains(setComboBox))
                        {
                            lastMatch = x;
                            found = false;
                        }
                        x++;
                    }
                }
            }
            else
                comboBoxLanguages.SelectedIndex = 0;
        }

        public void Get_Currency()
        {
            App._languageStorage = StorageClass.ReadXML<List<LanguageSettings>>("LanguageManageExpense.xml");
            if (App._languageStorage == null)
                App._languageStorage = new List<LanguageSettings>();
            var readlang = App._languageStorage;
            string setComboBox = "Euro";

            foreach (ComboBoxItem str in comboBoxLanguages.Items)
            {
                var updateItem = (from sett in App._languageStorage
                                  select sett);
                updateItem
                    .ToList().ForEach(exp =>
                    {
                        setComboBox = exp.choosenCurrency;
                    });
            }
            int x = 0;
            int lastMatch = 0;
            string match = setComboBox;
            // If the search string is empty set to begining of textBox
            if (setComboBox.Length != 0)
            {
                bool found = true;
                while (found)
                {
                    if (comboBoxCurrency.Items.Count == x)
                    {
                        comboBoxCurrency.SelectedIndex = lastMatch;
                        found = false;
                    }
                    else
                    {
                        comboBoxCurrency.SelectedIndex = x;
                        match = comboBoxCurrency.SelectedValue.ToString();
                        if (match.Contains(setComboBox))
                        {
                            lastMatch = x;
                            found = false;
                        }
                        x++;
                    }
                }
            }
            else
                comboBoxCurrency.SelectedIndex = 0;
        }

        public void Set_Language()
        {
            if (boolInit == false)
            {
                string itemFromGrid = ((ComboBoxItem)comboBoxLanguages.SelectedItem).Content as string;
                if (itemFromGrid.Equals("English"))
                { }
                else
                {
                    itemFromGrid = itemFromGrid.Substring(0, itemFromGrid.IndexOf(" "));
                }

                strLanguage = "XpenseManagerApp.Languages." + itemFromGrid;
                ResourceManager LocRM = new ResourceManager(strLanguage, typeof(MainWindow).Assembly);

               // FileMenu.Header = LocRM.GetString("file");
               // AnalyzeMenu.Header = LocRM.GetString("analyze");
               // ViewMenu.Header = LocRM.GetString("view");
               //// SaveMenu.Header = LocRM.GetString("save");
               // AddNewExpenMenu.Header = LocRM.GetString("new_Add");
               // ExitMenu.Header = LocRM.GetString("exit");
               // HomeMenu.Header = LocRM.GetString("home");
               // graph_Chart.Header = LocRM.GetString("graph_Menu");
               // PieChartMenu.Header = LocRM.GetString("pie_Chart");
               // TableMenu.Header = LocRM.GetString("table");
               // UpdateMenu.Header = LocRM.GetString("update");
               // settingPageText.Text = LocRM.GetString("settings");
               // settingText.Text = LocRM.GetString("select_language");
                //SettingMenu.Header = LocRM.GetString("settings");               
               
                
            }
        }

        public void Set_Currency()
        {
            if (boolInit == false)
            {
                string itemFromGrid = ((ComboBoxItem)comboBoxCurrency.SelectedItem).Content as string;
                if (itemFromGrid.Contains("Euro"))
                { }
                else
                {
                    itemFromGrid = itemFromGrid.Substring(0, itemFromGrid.IndexOf(" "));
                }

                strCurrency = "XpenseManagerApp.Languages.Currency";
                ResourceManager LocRM = new ResourceManager(strCurrency, typeof(MainWindow).Assembly);
                // FileMenu.Header = LocRM.GetString("file");
                if(itemFromGrid.Contains("Euro"))
                {
                    addNewExpense.currencyName.Text = LocRM.GetString("euro");
                    viewExpense.currencyName.Text = LocRM.GetString("euro");
                    updateExpense.currencyName.Text = LocRM.GetString("euro");
                } else
                if(itemFromGrid.Contains("Dollar"))
                {
                    addNewExpense.currencyName.Text = LocRM.GetString("dollar");
                    viewExpense.currencyName.Text = LocRM.GetString("dollar");
                    updateExpense.currencyName.Text = LocRM.GetString("dollar");
                } else
                if(itemFromGrid.Contains("Rupees"))
                {
                    addNewExpense.currencyName.Text = LocRM.GetString("rupees");
                    viewExpense.currencyName.Text = LocRM.GetString("rupees");
                    updateExpense.currencyName.Text = LocRM.GetString("rupees");
                } else
                if(itemFromGrid.Contains("Riyal"))
                {
                    addNewExpense.currencyName.Text = LocRM.GetString("riyal");
                    viewExpense.currencyName.Text = LocRM.GetString("riyal");
                    updateExpense.currencyName.Text = LocRM.GetString("riyal");
                } else
                if(itemFromGrid.Contains("Pound"))
                {
                    addNewExpense.currencyName.Text = LocRM.GetString("pound");
                    viewExpense.currencyName.Text = LocRM.GetString("pound");
                    updateExpense.currencyName.Text = LocRM.GetString("pound");
                }
                

            }
        }

        private void comboBoxCurrency_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Set_Currency();
        }

        private void comboBoxLanguages_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Set_Language();
        }

        private void SaveSettingsBtn_Click(object sender, RoutedEventArgs e)
        {
            foreach (ComboBoxItem str in comboBoxLanguages.Items)
            {
                var updateItem = (from sett in App._languageStorage
                                  select sett);
                updateItem
                   .ToList().ForEach(exp =>
                   {
                       exp.choosenCurrency = ((ComboBoxItem)comboBoxCurrency.SelectedItem).Content as string;
                       exp.choosenLanguage = ((ComboBoxItem)comboBoxLanguages.SelectedItem).Content as string;
                   });
                StorageClass.StoreXML<List<LanguageSettings>>("LanguageManageExpense.xml", App._languageStorage);
            }

            if (UserNameTxtBx.Text != null && UserNameTxtBx.Text != "")
            {
                if (UserDateofBirth.Text != null && UserDateofBirth.Text != "")
                {
                    if (PhoneNumberTxtBx.Text != null && PhoneNumberTxtBx.Text != "")
                    {
                        if (EmailTxtBx.Text != null && EmailTxtBx.Text != "")
                        { 
                            if (MaleRadioButton.IsChecked == true)
                            {
                                strGender = "Male";
                            }else
                            if (FemaleRadioButton.IsChecked == true)
                            {
                                strGender = "Female";
                            }else
                            if (OtherRadioButton.IsChecked == true)
                            {
                                strGender = "Other";
                            }else
                                {
                                    MessageBox.Show("Please select your Gender first",
                                        "Error");
                                }

                            
                            var checkUserInfo = (from x in App._userInfoClasses select x).Count();
                            if(checkUserInfo == 1)
                            {
                                var checkImage = (from xx in App._userInfoClasses
                                                  where xx.UserImageSave.Equals(saveUserImage)
                                                  select xx).FirstOrDefault();

                                if (checkImage == null)
                                {
                                    var updateImage = (from c in App._userInfoClasses
                                                       select c);
                                    updateImage.ToList().ForEach(ex => ex.UserImageSave = saveUserImage);
                                    StorageClass.StoreXML<List<UserInfoClass>>("UserIfo.xml",
                                        App._userInfoClasses);
                                }
                            }
                            else if( checkUserInfo == 0)
                            {
                                UserInfoClass datastore = new UserInfoClass
                                {
                                    UserName = UserNameTxtBx.Text,
                                    UserImageSave = saveUserImage,
                                    DateofBirth = UserDateofBirth.Text,
                                    PhoneNumber = PhoneNumberTxtBx.Text,
                                    Email = EmailTxtBx.Text,
                                    Gender = strGender
                                };

                                App._userInfoClasses.Add(datastore);
                                StorageClass.StoreXML<List<UserInfoClass>>("UserIfo.xml",
                                    App._userInfoClasses);
                                MessageBox.Show("Item Expense Saved!", "Alert!!!");
                            }
                           
                        }
                        else
                        {
                            MessageBox.Show("Fill All Fields!", "Error!!!");
                            Keyboard.Focus(EmailTxtBx);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Fill All Fields!", "Error!!!");
                        Keyboard.Focus(PhoneNumberTxtBx);
                    }
                }
                else
                {
                    MessageBox.Show("Fill All Fields!", "Error!!!");
                    Keyboard.Focus(UserDateofBirth);
                }
            }
            else
            {
                MessageBox.Show("Fill All Fields!", "Error!!!");
                Keyboard.Focus(UserNameTxtBx);
            }

            MessageBox.Show("Settings Updated!", "Alert!!!");
        }

        private void UserImage_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog();
            op.Title = "Select a picture";
            op.Filter = "All supported graphics|*.jpg;*.jpeg;*.png|" +
              "JPEG (*.jpg;*.jpeg)|*.jpg;*.jpeg|" +
              "Portable Network Graphic (*.png)|*.png";

            if (op.ShowDialog() == true)
            {
                saveUserImage = op.FileName;
                UserImage.Source = new BitmapImage(new Uri(op.FileName));
            }
        }

        private void Home_Menu_MouseDown(object sender, MouseButtonEventArgs e)
        {
            mainWindow.Width = 900;
            mainWindow.Height = 780;
            ItemDisplayGrid.Visibility = Visibility.Collapsed;
            DefaultGrid.Visibility = Visibility.Visible;
            settingsDisplayGrid.Visibility = Visibility.Collapsed;
        }

        private void Add_Expense_Menu_MouseDown(object sender, MouseButtonEventArgs e)
        {
            mainWindow.Width = 800;
            mainWindow.Height = 680;
            addNewExpense = new AddNewExpense();
            Set_Currency();
            DefaultGrid.Visibility = Visibility.Collapsed;
            ItemDisplayGrid.Visibility = Visibility.Visible;
            settingsDisplayGrid.Visibility = Visibility.Collapsed;
           
            ItemDisplayGrid.Children.Add(addNewExpense);
        }

        private void Exit_Expense_Menu_MouseDown(object sender, MouseButtonEventArgs e)
        {
            System.Windows.Application.Current.Shutdown();
        }

        private void Update_Expense_Menu_MouseDown(object sender, MouseButtonEventArgs e)
        {
            mainWindow.Width = 780;
            mainWindow.Height = 680;
            updateExpense = new UpdateExpense();
            Set_Currency();
            DefaultGrid.Visibility = Visibility.Collapsed;
            ItemDisplayGrid.Visibility = Visibility.Visible;
            settingsDisplayGrid.Visibility = Visibility.Collapsed;          
            ItemDisplayGrid.Children.Add(updateExpense);
        }

        private void Settings_Expense_Menu_MouseDown(object sender, MouseButtonEventArgs e)
        {
            strGender = "";
            mainWindow.Width = 800;
            mainWindow.Height = 650;

            var userinfos = (from users in App._userInfoClasses select users).LastOrDefault();
            if(userinfos != null)
            {
                UserNameTxtBx.Text = userinfos.UserName;
                UserDateofBirth.Text = userinfos.DateofBirth;
                EmailTxtBx.Text = userinfos.Email;
                PhoneNumberTxtBx.Text = userinfos.PhoneNumber;
                UserImage.Source = new BitmapImage(new Uri(userinfos.UserImageSave));
                strGender = userinfos.Gender;
                if (strGender.Equals("Male"))
                {
                    MaleRadioButton.IsChecked = true;
                    FemaleRadioButton.IsChecked = false;
                    OtherRadioButton.IsChecked = false;
                }
                else
                if (strGender.Equals("Female"))
                {
                    MaleRadioButton.IsChecked = false;
                    FemaleRadioButton.IsChecked = true;
                    OtherRadioButton.IsChecked = false;
                }
                else
                if (strGender.Equals("Other"))
                {
                    MaleRadioButton.IsChecked = false;
                    FemaleRadioButton.IsChecked = false;
                    OtherRadioButton.IsChecked = true;
                }
            }

            DefaultGrid.Visibility = Visibility.Collapsed;
            ItemDisplayGrid.Visibility = Visibility.Collapsed;
            settingsDisplayGrid.Visibility = Visibility.Visible;
            RaiseCurrencySelectionChanged();
            RaiseLanguageSelectionChanged();

        }

        private void Graph_Expense_Menu_MouseDown(object sender, MouseButtonEventArgs e)
        {
            mainWindow.Width = 900;
            mainWindow.Height = 750;
            DefaultGrid.Visibility = Visibility.Collapsed;
            ItemDisplayGrid.Visibility = Visibility.Visible;
            settingsDisplayGrid.Visibility = Visibility.Collapsed;
            var graphChartShow = new GraphChartUserControl();
            ItemDisplayGrid.Children.Add(graphChartShow);
        }

        private void Area_Expense_Menu_MouseDown(object sender, MouseButtonEventArgs e)
        {
            mainWindow.Width = 900;
            mainWindow.Height = 750;
            DefaultGrid.Visibility = Visibility.Collapsed;
            ItemDisplayGrid.Visibility = Visibility.Visible;
            settingsDisplayGrid.Visibility = Visibility.Collapsed;
            var areaChartUserControl = new AreaChartUserControl();
            ItemDisplayGrid.Children.Add(areaChartUserControl);
        }

        private void Pie_Expense_Menu_MouseDown(object sender, MouseButtonEventArgs e)
        {
            mainWindow.Width = 900;
            mainWindow.Height = 750;
            DefaultGrid.Visibility = Visibility.Collapsed;
            ItemDisplayGrid.Visibility = Visibility.Visible;
            settingsDisplayGrid.Visibility = Visibility.Collapsed;
            var pieChartShow = new PieChartControl();
            ItemDisplayGrid.Children.Add(pieChartShow);
        }

        private void View_Expense_Menu_MouseDown(object sender, MouseButtonEventArgs e)
        {
            mainWindow.Width = 750;
            mainWindow.Height = 680;
            viewExpense = new ViewExpense();
            DefaultGrid.Visibility = Visibility.Collapsed;
            ItemDisplayGrid.Visibility = Visibility.Visible;
            settingsDisplayGrid.Visibility = Visibility.Collapsed;
            Set_Currency();
            ItemDisplayGrid.Children.Add(viewExpense);
        }

        private void Home_Menu_MouseEnter(object sender, MouseEventArgs e)
        {
            Home_Menu.Height = 70;
            Home_Menu.Width = 70;
        }

        private void Home_Menu_MouseLeave(object sender, MouseEventArgs e)
        {
            Home_Menu.Height = 40;
            Home_Menu.Width = 40;
        }

        private void Add_Expense_Menu_MouseEnter(object sender, MouseEventArgs e)
        {
            Add_Expense_Menu.Height = 70;
            Add_Expense_Menu.Width = 70;
        }

        private void Add_Expense_Menu_MouseLeave(object sender, MouseEventArgs e)
        {
            Add_Expense_Menu.Height = 40;
            Add_Expense_Menu.Width = 40;
        }

        private void Update_Expense_Menu_MouseEnter(object sender, MouseEventArgs e)
        {
            Update_Expense_Menu.Height = 70;
            Update_Expense_Menu.Width = 70;
        }

        private void Update_Expense_Menu_MouseLeave(object sender, MouseEventArgs e)
        {
            Update_Expense_Menu.Height = 40;
            Update_Expense_Menu.Width = 40;
        }

        private void View_Expense_Menu_MouseEnter(object sender, MouseEventArgs e)
        {
            View_Expense_Menu.Height = 70;
            View_Expense_Menu.Width = 70;
        }

        private void View_Expense_Menu_MouseLeave(object sender, MouseEventArgs e)
        {
            View_Expense_Menu.Height = 40;
            View_Expense_Menu.Width = 40;
        }

        private void Pie_Expense_Menu_MouseEnter(object sender, MouseEventArgs e)
        {
            Pie_Expense_Menu.Height = 70;
            Pie_Expense_Menu.Width = 70;
        }

        private void Pie_Expense_Menu_MouseLeave(object sender, MouseEventArgs e)
        {
            Pie_Expense_Menu.Height = 40;
            Pie_Expense_Menu.Width = 40;
        }

        private void Area_Expense_Menu_MouseEnter(object sender, MouseEventArgs e)
        {
            Area_Expense_Menu.Height = 70;
            Area_Expense_Menu.Width = 70;
        }

        private void Area_Expense_Menu_MouseLeave(object sender, MouseEventArgs e)
        {
            Area_Expense_Menu.Height = 40;
            Area_Expense_Menu.Width = 40;
        }

        private void Graph_Expense_Menu_MouseEnter(object sender, MouseEventArgs e)
        {
            Graph_Expense_Menu.Height = 70;
            Graph_Expense_Menu.Width = 70;
        }

        private void Graph_Expense_Menu_MouseLeave(object sender, MouseEventArgs e)
        {
            Graph_Expense_Menu.Height = 40;
            Graph_Expense_Menu.Width = 40;
        }

        private void Exit_Expense_Menu_MouseEnter(object sender, MouseEventArgs e)
        {
            Exit_Expense_Menu.Height = 70;
            Exit_Expense_Menu.Width = 70;
        }

        private void Exit_Expense_Menu_MouseLeave(object sender, MouseEventArgs e)
        {
            Exit_Expense_Menu.Height = 40;
            Exit_Expense_Menu.Width = 40;
        }

        private void MenuStackPanel_MouseEnter(object sender, MouseEventArgs e)
        {  
            MenuStackPanel.Background = new SolidColorBrush(Colors.White);
        }

        private void MenuStackPanel_MouseLeave(object sender, MouseEventArgs e)
        {
            MenuStackPanel.Background = new SolidColorBrush(Colors.Transparent);
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            ItemDisplayGrid.Visibility = Visibility.Collapsed;
            DefaultGrid.Visibility = Visibility.Visible;
            settingsDisplayGrid.Visibility = Visibility.Collapsed;
        }

        private void Settings_Expense_Menu_MouseEnter(object sender, MouseEventArgs e)
        {
            Settings_Expense_Menu.Height = 70;
            Settings_Expense_Menu.Width = 70;
        }

        private void Settings_Expense_Menu_MouseLeave(object sender, MouseEventArgs e)
        {
            Settings_Expense_Menu.Height = 40;
            Settings_Expense_Menu.Width = 40;
        }

        
    }
}
