﻿ using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Resources;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace XpenseManagerApp
{
    public partial class App : Application
    {
        public static List<ViewDatafromCSV> _datastorage;
        public static List<ShowChart> _showCharts;
        public static List<LanguageSettings> _languageStorage;
        public static List<UserInfoClass> _userInfoClasses;

        private void Application_Startup(object sender, StartupEventArgs e)
        {
            _datastorage = StorageClass.ReadXML<List<ViewDatafromCSV>>("ExpenseManager.xml");
            if (_datastorage == null)
                _datastorage = new List<ViewDatafromCSV>();
            _languageStorage = StorageClass.ReadXML<List<LanguageSettings>>("LanguageManageExpense.xml");
            if (_languageStorage == null)
                _languageStorage = new List<LanguageSettings>();
            _userInfoClasses = StorageClass.ReadXML<List<UserInfoClass>>("UserIfo.xml");
            if (_userInfoClasses == null)
                _userInfoClasses = new List<UserInfoClass>();
            if (_showCharts == null)
                _showCharts = new List<ShowChart>();
            //LanguageSettings languages = new LanguageSettings { choosenLanguage = "English"};
            // _languageStorage = new List<LanguageSettings> { languages };
            //  StorageClass.StoreXML<List<LanguageSettings>>("LanguageManageExpense.xml", _languageStorage);
        }

        private void Application_Exit(object sender, ExitEventArgs e)
        {
           
            //int countItems = 1; 
            //ViewDatafromCSV datastore = new ViewDatafromCSV { productId = countItems, itemName = "Item1" , boughtDate = DateTime.Now, category = "Electronics", amount = "45.00" };
            // countItems += 1;
            // ViewDatafromCSV datastore1 = new ViewDatafromCSV { productId = countItems, itemName = "Item2", boughtDate = DateTime.Now, category = "Rent", amount = "275.00" };
            // countItems += 1;
            // ViewDatafromCSV datastore2 = new ViewDatafromCSV { productId = countItems, itemName = "Item3", boughtDate = DateTime.Now, category = "Restaurant", amount = "25.00" };

            // _datastorage = new List<ViewDatafromCSV> { datastore, datastore1, datastore2 };

            //StorageClass.StoreXML<List<ViewDatafromCSV>>("ExpenseManager.xml", _datastorage);
        }
    }

       
}
