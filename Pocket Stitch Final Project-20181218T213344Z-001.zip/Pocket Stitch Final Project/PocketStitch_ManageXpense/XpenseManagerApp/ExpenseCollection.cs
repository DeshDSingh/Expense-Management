﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XpenseManagerApp
{
    class ExpenseCollection: System.Collections.ObjectModel.Collection<ShowChart>
    {       
        public ExpenseCollection()
        {
            var itemToUpdate = (from expense in App._datastorage
                                orderby expense.category
                                select expense);
            List<string> strCat = new List<string>();

            List<float> totalPrice = new List<float>();

            float totalPriceChange = 0;
            itemToUpdate
                .ToList().ForEach(exp =>
                {
                    var addcategory = (from adder in strCat
                                   where adder.Equals(exp.category)
                                   select adder).FirstOrDefault();
                    if(addcategory == null)
                    {
                        if(totalPriceChange != 0 )
                        {
                            totalPrice.Add(totalPriceChange);
                        }
                        totalPriceChange = 0;
                        totalPriceChange = exp.itemPrice * exp.itemQuantity;
                        strCat.Add(exp.category); 
                    }
                    else
                    {
                        totalPriceChange = totalPriceChange + exp.itemPrice * exp.itemQuantity;                       
                    }
                });

            totalPrice.Add(totalPriceChange);
           
            for (int i = 0; i< strCat.Count; i++)
            {

                Add(new ShowChart
                {
                    category = strCat[i],
                    totalAmount = totalPrice[i]
                });


            }
        }
    }
}
