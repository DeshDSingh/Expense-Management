﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XpenseManagerApp
{
    public class LanguageSettings
    {
        public LanguageSettings(string choosenLanguages)
        {
            choosenLanguage = choosenLanguages;
        }

        public LanguageSettings()
        { }

        public string choosenLanguage { get; set; }
        public string choosenCurrency { get; set; }
        //public string german { get; set; }
        //public string hindi { get; set; }
        //public string english { get; set; }
        //public string spanish { get; set; }
        //public string chinese { get; set; }
        //public string choosenLanguage { get; set; }

    }
}
