﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Xml.Serialization;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace XpenseManagerApp
{
    /// <summary>
    /// Interaction logic for ViewExpense.xaml
    /// </summary>
    public partial class ViewExpense : UserControl
    {
        public ViewExpense()
        {
            InitializeComponent();
            DisplayinGrid();
           
        }

        public void DisplayinGrid()
        {
            dgExpenseStorage.ItemsSource = App._datastorage;
            float totalSpent = (from expense in App._datastorage
                                select expense.totalAmount).Sum();
            SpentTotal.Text = totalSpent.ToString();
        }

        private void txtboxFilter_TextChanged(object sender, TextChangedEventArgs e)
        {
            //var filterResult = (from expense in App._datastorage where
            //                    expense.itemName.StartsWith(txtboxFilter.Text,
            //                    StringComparison.InvariantCultureIgnoreCase)
            //                    select expense);
            //lbxExpenseStorage.ItemsSource = filterResult;
            if (txtboxFilter.Text == null || txtboxFilter.Text.Equals(""))
            {
                dgExpenseStorage.ItemsSource = App._datastorage;
                float totalSpent = (from expense in App._datastorage
                                    select expense.totalAmount).Sum();
                SpentTotal.Text = totalSpent.ToString();
            }
            else
            {
                var filterResult = (
                    from expense in App._datastorage where (expense.itemName.StartsWith(txtboxFilter.Text,
                               StringComparison.InvariantCultureIgnoreCase)
                               || expense.itemPrice.ToString().
                               StartsWith(txtboxFilter.Text,
                                    StringComparison.InvariantCultureIgnoreCase)
                               || expense.itemQuantity.ToString().StartsWith(txtboxFilter.Text,
                                    StringComparison.InvariantCultureIgnoreCase)
                               || expense.totalAmount.ToString().StartsWith(txtboxFilter.Text,
                                    StringComparison.InvariantCultureIgnoreCase)
                               || expense.category.StartsWith(txtboxFilter.Text,
                               StringComparison.InvariantCultureIgnoreCase)
                               || expense.boughtDate.StartsWith(txtboxFilter.Text,
                               StringComparison.InvariantCultureIgnoreCase)
                               )select expense);
                dgExpenseStorage.ItemsSource = filterResult;
            }
           
        }
    }
}
